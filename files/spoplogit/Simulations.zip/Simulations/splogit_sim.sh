#!/bin/bash

cd splogit

#MOAB -N ab_test            # Name the job for moab.
#MOAB -q polisci_q          # Put it in the polisci queue.
#MOAB -u ab05h
#MOAB -l walltime=168:00:00
#MOAB -l nodes=2
#MOAB -j oe
#MOAB -m e                  # Email notification for when a job ends.

cd $PBS_O_WORKDIR

source /panfs/storage.local/opt/stata10/setup-stata.sh

stata-mp -b do splogit_sim.do
